package com.bit.studypage.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;


public class HomeBoard {

}
