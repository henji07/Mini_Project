package com.bit.studypage.dto.board;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class FileQnaDTO {
	
	private Long id;
	private String fileName;
	private String fileType;
	private String filePath;
}
