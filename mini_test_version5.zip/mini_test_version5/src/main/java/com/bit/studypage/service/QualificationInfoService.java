package com.bit.studypage.service;

import com.bit.studypage.entity.QualificationInfo;

public interface QualificationInfoService {
    QualificationInfo getInfo(String name);
}
