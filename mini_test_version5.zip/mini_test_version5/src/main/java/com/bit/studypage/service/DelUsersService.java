package com.bit.studypage.service;

import com.bit.studypage.entity.DelUsers;
import com.bit.studypage.entity.Users;

public interface DelUsersService {
    void setDelUser(DelUsers user);
}
