package com.bit.studypage.dto;

public class HomeDTO {
}
